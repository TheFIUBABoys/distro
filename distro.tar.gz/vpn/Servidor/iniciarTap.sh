
openvpn ./hostA.conf &
#openvpn ./hostB.conf &
#openvpn ./hostC.conf &

#openvpn ./telServer1.conf &
#openvpn ./telServer2.conf &

#openvpn ./webServer.conf &

#openvpn ./ftpServer.conf &

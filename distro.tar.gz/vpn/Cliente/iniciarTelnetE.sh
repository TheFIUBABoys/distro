
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1201 10.61.6.129 255.255.255.224

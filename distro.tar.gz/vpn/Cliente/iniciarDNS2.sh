
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1196 10.111.25.197 255.255.255.192


# $1 -> Ip del servidor

./iniciarCliente.sh $1 1199 192.168.25.1 255.255.255.0

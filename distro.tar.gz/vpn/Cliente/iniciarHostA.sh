
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1202 10.111.25.165 255.255.255.240

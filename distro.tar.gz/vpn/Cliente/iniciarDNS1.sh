
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1195 10.111.25.131 255.255.255.224

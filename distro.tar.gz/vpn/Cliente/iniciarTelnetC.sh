
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1200 10.61.5.130 255.255.255.0


# $1 -> Ip del servidor

./iniciarCliente.sh $1 1198 10.111.25.1 255.255.255.128

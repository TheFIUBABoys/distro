
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1197 192.168.25.7 255.255.255.0

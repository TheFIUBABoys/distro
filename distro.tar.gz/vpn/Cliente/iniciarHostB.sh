
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1203 10.61.5.131 255.255.255.0

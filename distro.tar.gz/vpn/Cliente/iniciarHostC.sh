
# $1 -> Ip del servidor

./iniciarCliente.sh $1 1204 192.168.25.8 255.255.255.0
